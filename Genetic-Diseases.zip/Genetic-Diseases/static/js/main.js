// Main JavaScript file for Genetic Disease Predictor
// This file contains common functions used across the application

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Genetic Disease Predictor initialized');
});

// Common utility functions
window.GeneticPredictor = {
    // Function to format percentages
    formatPercentage: function(value) {
        return (value * 100).toFixed(1) + '%';
    },
    
    // Function to get risk color class
    getRiskColorClass: function(riskLevel) {
        switch(riskLevel) {
            case 'Low':
            case 'Very Low':
                return 'text-green-600';
            case 'Moderate':
                return 'text-yellow-600';
            case 'High':
            case 'Very High':
                return 'text-red-600';
            default:
                return 'text-gray-600';
        }
    }
};